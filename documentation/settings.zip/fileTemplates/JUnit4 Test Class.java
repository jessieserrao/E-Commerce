import static org.assertj.core.api.Assertions.*;

import org.assertj.core.api.Assertions;

import static org.mockito.Mockito.*;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.spy;
import org.junit.runner.RunWith;
import org.junit.Test;
import org.junit.Before;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import lombok.SneakyThrows;
#parse("File Header.java")
@RunWith(MockitoJUnitRunner.class)
public class ${NAME} {
    #set ($end_index = $NAME.length() - 4)
#set ($class = $NAME.substring(0,$end_index))  
    private $class $class.substring(0,1).toLowerCase()$class.substring(1);
    
    //@Mock Class name;
    
    @Before
    public void setUp(){
        $class.substring(0,1).toLowerCase()$class.substring(1) = spy(new $class());
    }
   
    @lombok.SneakyThrows @org.junit.Test
    public void ${NAME}() {
        // arrange
        //when();
        
        // act
        // $class.substring(0,1).toLowerCase()$class.substring(1).
        ${BODY}
        
        // assert
        assertThat(1).isEqualTo(1);
        verify($class.substring(0,1).toLowerCase()$class.substring(1));
    }
}